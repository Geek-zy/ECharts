<?php

$URL = $_SERVER['HTTP_HOST'];

echo 
	"<meta charset='utf-8'><pre><h1>图表名称			访问地址</h1><pre>" .
	"<pre><h2>" .
	"全年全国医院、各医院、例数统计图	<a href=http://$URL/Map/Map_Count>http://$URL/Map/Map_Count</a><br>" .
	"全年全国医院、各医院、存储量统计图	<a href=http://$URL/Map/Map_Size>http://$URL/Map/Map_Size</a><br>" .
	"全国所有影像中心的位置		<a href=http://$URL/Map/Map_Rimag_Position>http://$URL/Map/Map_Rimag_Position</a><br>" .
	"各医院发起远程会诊			<a href=http://$URL/Map/Map_Remote_Diagnosis>http://$URL/Map/Map_Remote_Diagnosis</a><br>" .
	"患者实时动态数据系统		<a href=http://$URL/Map/Map_LED_List>http://$URL/Map/Map_LED_List</a></h2></pre>";
?>
