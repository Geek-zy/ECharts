
var myDate = new Date();
var Date_Time = myDate.getFullYear() - 1;

var Json_Data;

function GET_Json_Data() {

	    $.ajax({

			url:"../../../API/Map_Hosp.php",
		type:"get",
		async:false,
		dataType:"json",

		success:function(data){

			Json_Data = data;
		},

		error:function(data){

			console.log(data);
		}
		});
}

GET_Json_Data();
//海拉尔农垦总医院
var Data_81 = Json_Data[81].patientsize;
////八仙筒镇卫生院
var Data_82 = Json_Data[82].patientsize;
////库伦旗医院
var Data_83 = Json_Data[83].patientsize;
////通辽市精神卫生中心
var Data_107 = Json_Data[107].patientsize;
////内蒙古赤峰松山医院
var Data_121 = Json_Data[121].patientsize;
////赤峰市巴林左旗医院
var Data_123 = Json_Data[123].patientsize;
//内蒙古赤峰松山中蒙医院
var Data_159 = Json_Data[159].patientsize;
//通辽市传染病医院
var Data_161 = Json_Data[161].patientsize;
////科左中旗中医院
var Data_162 = Json_Data[162].patientsize;
//内蒙古通辽市保康蒙医院
var Data_167 = Json_Data[167].patientsize;
////巴彦淖尔市杭锦后旗同济医院
var Data_170 = Json_Data[170].patientsize;
////清水河县人民医院
var Data_171 = Json_Data[171].patientsize;
////土默特左旗人民医院
var Data_172 = Json_Data[172].patientsize;
////内蒙古五原县人民医院
var Data_180 = Json_Data[180].patientsize;
////察右后旗医院
var Data_190 = Json_Data[190].patientsize;

require.config({
	paths: {
		//echarts: 'http://echarts.baidu.com/build/dist'
		echarts: '../../../Echarts'
	}
});

require (

			[
			'echarts',
			'echarts/chart/map'
			],

			function (ec) {
				var myChart = ec.init(document.getElementById('main'));

				myChart.setOption(option);
			}
		);
