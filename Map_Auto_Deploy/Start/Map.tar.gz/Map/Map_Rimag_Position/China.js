
option = {

	title : {

		text: '一脉阳光影像中心分布图',
		//subtext: 'RIMAG--center--data',
		//sublink: 'http://www.rimag.com.cn',

		x:'center',
		textStyle:{color:'red'},
	},

	tooltip : {

		trigger: 'item'

	},
	//添加左上角标题颜色，分别为深灰色，草绿色
	color:['darkgray','lime'],

	legend: {

		orient: 'vertical',

		x:'left',
		data:['在建影像中心','运营影像中心'],
		textStyle: {color:'lime'},
	},

	dataRange: {

		min : 0,

			max : 1,

			calculable : true,

			color: ['lime', 'darkgray']

	},

	series : [

	{

		name: '在建影像中心.',

		type: 'map',

		mapType: 'china',

		hoverable: false,

		roam:true,

		itemStyle:{

			normal:{

				label:{show:true}, //省名显示

				emphasis:{label:{show:true}},

				borderColor:'rgba(100,149,237,4)',

				borderWidth:0.5,

				areaStyle:{color: '#1b1b1b'}

			}

		},

		data : [],

		markPoint : {

			symbolSize: 8,

			itemStyle: {

				normal: {

					borderColor: 'darkpray',

					borderWidth: 0,

					label:{show:false}},

				emphasis: {

					borderColor: 'darkgray',

					borderWidth: 4,

					label: {show: false}},

			},

			data : [
			//江西
			{name: "赣州", value: 0},
			{name: "新余市人民医院", value: 0},
			{name: "新余市中医院", value: 0},
			{name: "新余市妇幼保健院", value: 0},
			{name: "宁都县人民医院", value: 0},
			{name: "铜鼓县人民医院", value: 0},
			{name: "安福县人民医院", value: 0},
			{name: "永修县人民医院", value: 0},
			{name: "抚州市人民医院", value: 0},
			{name: "南城县人民医院", value: 0},
			{name: "兴国县", value: 0},
			//内蒙
			{name: "内蒙古清水河县医院", value: 0},
			{name: "天津市职业病防治医院", value:0},
			{name: "赤峰市喀喇沁旗医院", value: 0},
			//湖北
			{name: "隆回县中医院", value: 0},
			{name: "洞口县人民医院", value: 0},
			{name: "资兴市地区", value: 0},
			{name: "汉寿县中医院", value: 0},
			{name: "长沙市独立影像中心", value: 0},
			{name: "辰溪县人民医院", value: 0},
			{name: "南县中医院", value: 0},
			//广西
			{name: "玉林兴业影像中心", value: 0},
			{name: "河池东兰影像中心", value: 0},
			{name: "河池南丹影像中心", value: 0},
			{name: "柳州鹿寨影像中心", value: 0},
			{name: "来宾象州影像中心", value: 0},
			{name: "钦州灵山影像中心", value: 0},
			{name: "全州县影像中心", value: 0 },
			//广东
			{name: "湛江农垦中心医院", value:0},
			{name: "广州从化影像中心", value:0},
			{name: "肇庆市独立影像中心", value:0},
			//海南
			{name: "海南省农垦那大医院", value:0},
			//山东
			{name: "云浮市人民医院", value: 0},
			{name: "临邑县中医院", value: 0},
			{name: "庆云县影像中心", value: 0},
			{name: "罗庄区中心医院", value: 0},
			{name: "德州二院", value: 0},


			]

		},

		geoCoord: {

			'赣州' :[114.935909,25.845296],
			'新余市人民医院':[114.94222,27.803569],
			'新余市中医院':[114.947117,27.822322],
			'新余市妇幼保健院':[114.948135,27.807114],
			'宁都县人民医院':[116.015166,26.455258],
			'铜鼓县人民医院':[114.374866,28.526296],
			'安福县人民医院':[114.620746,27.384616],
			'永修县人民医院':[115.81305,29.021612],
			'抚州市人民医院':[116.360919,27.954545],
			'南城县人民医院':[116.3609,39.943309],
			'内蒙古清水河县医院':[111.683365,39.917953],
			'天津市职业病防治医院':[117.210813,39.14393],
			'赤峰市喀喇沁旗医院':[118.704278,41.931846],
			'隆回县中医院':[110.973326,27.351831],
			'洞口县人民医院':[110.580512,27.060516],
			'资兴市地区':[113.468522,25.937184],
			'汉寿县中医院':[111.979415,28.913401],
			'长沙市独立影像中心':[112.979353,28.213478],
			'辰溪县人民医院':[110.199899,28.009866],
			'南县中医院':[112.41219,29.37602],
			'玉林兴业影像中心':[109.928611,22.798462],
			'河池东兰影像中心':[107.413534,24.5116],
			'河池南丹影像中心':[107.468001,25.119439],
			'柳州鹿寨影像中心':[109.802816,24.532198],
			'来宾象州影像中心':[109.771968,24.01917],
			'钦州灵山影像中心':[109.147748,22.315716],
			'全州县影像中心':[111.026435,25.936465],
			'湛江农垦中心医院':[110.407597,21.219497],
			'广州从化影像中心':[113.698709,23.705203],
			'肇庆市独立影像中心':[112.479653,23.078663],
			'海南省农垦那大医院':[109.582845,19.512434],
			'云浮市人民医院':[112.080194,22.957752],
			'临邑县中医院':[116.874559,37.195702],
			'庆云县影像中心':[117.462737,37.801824],
			'罗庄区中心医院':[118.297279,34.964343],
			'德州二院':[116.328161,37.460826],

		}

	},

	{

		name: '运营影像中心',

		type: 'map',

		mapType: 'china',

		hoverable: false,

		roam:true,

		itemStyle:{

			normal:{

				label:{show:true}, //省名显示
				emphasis:{label:{show:true}},
				borderColor:'rgba(100,149,237,4)',
				borderWidth:0.5,
				areaStyle:{color: '#1b1b1b'}

			}

		},

		data : [],

		markPoint : {

			symbolSize: 8,

			itemStyle: {

				normal: {

					borderColor: 'darkpray',

					borderWidth: 0,

					label:{show:false}},

				emphasis: {

					borderColor: 'darkgray',

					borderWidth: 4,

					label: {show: false}},

			},

			data : [

			{name: "北京", value: 1},
			{name: "南昌", value: 1},
			{name: "德州十三局医院", value: 1},
			{name: "荆门二院", value: 1},
			{name: "海拉尔农垦总医院", value: 1},
			{name: "赣州市", value: 1},
			{name: "万安县", value: 1},
			{name: "上高县", value: 1},
			{name: "分宜县", value: 1},
			{name: "景德镇市", value: 1},
			]

		},

		geoCoord: {

			'北京': [116.4551,40.2539],
			'南昌': [116.0046,28.6633],
			'赣州市':[114.940278,25.85097],
			'分宜县': [114.67,27.82],
			'景德镇市': [117.17,29.27],
			'上高县': [114.92,28.23],
			'兴国县': [115.35,26.33],
			'万安县': [114.78,26.47],
			'海拉尔农垦总医院':[119.74889787081258,49.23019572730968],
			'荆门二院':[112.28990431128734,30.311471611801725],
			'德州十三局医院':[116.3166946653024,37.44957765511814],

		}

	},

	]

};


