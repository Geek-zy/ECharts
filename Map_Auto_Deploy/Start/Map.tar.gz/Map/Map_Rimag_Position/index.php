<!DOCTYPE html>

<html>

<head>
	<meta charset="utf-8">
	<!--meta http-equiv="refresh" content="10"-->
	<!--meta http-equiv="refresh" content="3;url=../Beijing/"--> 
	<title>一脉阳光影像中心分布图</title>
</head>

<!--	<body style="background:#1b1b1b">-->
	<body style="background:#1B1B1B">


	<div id="main" style="height:800px"></div>
	<script type="text/javascript" src="../Echarts/echarts.js"></script>
	<!--script src="http://echarts.baidu.com/build/dist/echarts.js"></script-->
	<script type="text/javascript" src="Data.js"></script>
	<script type="text/javascript" src="China.js"></script>
  
	</body>  
</html>
