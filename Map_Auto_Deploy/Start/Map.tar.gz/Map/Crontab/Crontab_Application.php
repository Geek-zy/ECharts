<?php
		$dir = dirname('__FILE__');
		require_once ("$dir/Mysql.php");

		//$begin = "2015-10-01";
		$begin = date("Y-m-d", strtotime("1 days ago")); 
		$endTime = date("Y-m-d");
		$URL  = 'http://web.rimag.com.cn/Interfaces/Patient/ApplicationCount/startTime/'. $begin . '/endTime/' . $endTime;
		$data = json_decode(file_get_contents($URL),true);
	function placeholders($text, $count=0, $separator=","){
	    $result = array();
	    if($count > 0){
	        for($x=0; $x<$count; $x++){
	            $result[] = $text;
	        }
	    }

	    return implode($separator, $result);
	}

	$pdo = Connection();
	$pdo->beginTransaction(); // also helps speed up your inserts.
	$insert_values = array();
	foreach($data as $d){
	    $question_marks[] = '('  . placeholders('?', sizeof($d)) . ')';
	    $insert_values = array_merge($insert_values, array_values($d));
	}
	$datafields = array('Applicationid','patient_cname','expert_hospital_id','expert_hospital','application_hospital_id','application_hospital','inspect_time');
	
	$sql = "INSERT INTO Application (" . implode(",", $datafields ) . ") VALUES " . implode(',', $question_marks);
	
	$stmt = $pdo->prepare($sql);

	
	try {
	    $stmt->execute($insert_values);
	} catch (PDOException $e){
	    echo $e->getMessage();
	}
	$pdo->commit();
