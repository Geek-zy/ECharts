<?php

function Connection(){
        try {
                $pdo = new PDO('mysql:host=127.0.0.1;dbname=rimag_show;charset=utf8','root','root');
        }catch(PDOException $e){
                print "Error!:" . $e->getMessage() . "<br/>";
                exit;
        }
        return $pdo;
}
function mysqli_connection(){

	$servername = "localhost";
	$username = "root";
	$password = "root";
	$dbname = "rimag_show";

	// 创建连接
	$conn = new mysqli($servername, $username, $password, $dbname);
	mysqli_set_charset($conn,"utf8");
	return $conn;

}

function formatSizeUnits($bytes){
			if ($bytes >= 1073741824 )
			{
				$bytes = number_format($bytes / 1073741824, 2,".",""); //换成G,最小值为1G;
			}
			elseif($bytes >= 10485760){
				$bytes = number_format($bytes / 1073741824, 4,".",""); //换成G，最小值为10MB;
			}
			else{
				$bytes = '0.00'; 	//小于10MB,不计数;
			}
			return $bytes;
		}

function insert_application($hospital_id,$appcount){
		$pdo = Connection();
		$stmt = $pdo->prepare("insert into Application(hospital_appid,app_count) values(?,?)");
		 $stmt->bindParam(1,$hospital_id);
		 $stmt->bindParam(2,$appcount);
		 $stmt->execute();

}
function update_application($hospital_id,$appcount){
		$pdo = Connection();
		$stmt = $pdo->prepare("update Application set app_count=$appcount where hospital_appid=$hospital_id");
		$stmt->execute();

}
