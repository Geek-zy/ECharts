<?php
$dir = dirname('__FILE__');
require_once ("$dir/Mysql.php");


/*
	生成医院列表数据,获取每月硬盘使用量和患者人数;	
*/
$web_Url = "http://web.rimag.com.cn/Interfaces/index/getHospitalAetList/";
$ArrayList = json_decode(file_get_contents($web_Url),true);
$StorageList = array();
/*
foreach($ArrayList as $key=>$value){
	if($value['is_center'] != 0 and $value['hospital_id'] !=202 or $value['hospital_id'] == 74){
		$StorageList[] = $value['hospital_id'];
		}
}
*/
foreach($ArrayList as $key=>$value){
		$StorageList[] = $value['hospital_id'];
}

//print_r($StorageList);exit;

$Storage_Data = array();
$List = array();
	foreach($StorageList as $key=>$value){
		//for($i=0; $i<=10; $i++){

			//$month = date("m",mktime(0,0,0,date("m")-$i,01,date("Y")));
			
			$startDate = date('Y') .'-' . date('m') . '-01';
			$endDate =  date('Y') .'-' .date('m') .'-31';
			$hospital_id = $value;
			$storage_url ="http://web.rimag.com.cn/Interfaces/AetFilesize/fetchHospitalSize?hospitalId=$hospital_id&startDate=$startDate&endDate=$endDate";

			$count_data = json_decode(file_get_contents($storage_url),true);
			foreach($count_data as $key1=>$value1){
				$patientsize = formatSizeUnits($value1['totalsize']);
				if($patientsize != '0.00'){
				$Storage_Data = array(
					'hospital_id' => $hospital_id,
					'date' => "$startDate",
					'patientsize' => $patientsize,
					'patientcount' => $value1['totalcount']
					);
					array_push($List,$Storage_Data);
				}
			}

		}
	//	}
print_r($List);exit;


/*
	插入数据库
*/

function insert($conn,$Array_hospital){
        if(empty($Array_hospital)){
                echo 'hospital is not exist';
                exit;
        }else{
		$sql = "insert into storage_data(hospital_fk,patient_count,patient_size,date) values(?,?,?,?)";
		$stmt = mysqli_stmt_init($conn);
		
		if(mysqli_stmt_prepare($stmt,$sql)){
			mysqli_stmt_bind_param($stmt,'iids',$hospital_fk,$patient_count,$patient_size,$date);
			foreach($Array_hospital as $key=>$value){
				$hospital_fk = $value['hospital_id'];
				$patient_count = $value['patientcount'];
				$patient_size = $value['patientsize'];
				$date = $value['date'];
				mysqli_stmt_execute($stmt);
				}
				
			}
        }
}
function update($conn,$List){
	foreach ($List as $key => $value) {
		if(!empty($value['patientcount'])){
			$hospital_id=$value['hospital_id'];
			$date=$value['date'];
			$patientcount=$value['patientcount'];
			$patientsize = $value['patientsize'];
			if(!empty($patientcount)){
				$sql = "update storage_data set patient_count=$patientcount,patient_size=$patientsize where date='".$date."' and hospital_fk=$hospital_id";
					if($conn->query($sql) != TRUE){
						echo "Error" . $sql ."\n";
			}
		}
	}

  }
}
$conn = mysqli_connection();

	if(date('d') == '01'){
		insert($conn,$List);
	}else{
		update($conn,$List);
	}
$conn = null;
