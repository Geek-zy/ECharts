<!DOCTYPE html>

<html>

<head>
	<meta charset="utf-8">
	<!--meta http-equiv="refresh" content="12"-->
	<!--meta http-equiv="refresh" content="10;url=../Beijing/"--> 
	<title>一脉阳光全国各医院存储量</title>
</head>

	<body style="background:#1B1B1B">  
	<br>

	<div id="main" style="height:900px"></div>
	<script type="text/javascript" src="../../Echarts/jquery-1.8.0.js"></script>
	<script type="text/javascript" src="../../Echarts/echarts.js"></script>
	<!--script src="http://echarts.baidu.com/build/dist/echarts.js"></script-->
	<script type="text/javascript" src="Data.js"></script>
	<script type="text/javascript" src="China.js"></script>
  
	</body>  
</html>
