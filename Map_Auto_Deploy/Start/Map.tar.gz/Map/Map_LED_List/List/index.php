<!DOCTYPE html>

<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<script type="text/javascript" src="../../Echarts/jquery-1.8.0.js"></script>
	<script type="text/javascript" src="jQuery_Plug.js"></script>
	<style type="text/css">@import url(List.css);</style>
</head>

<body style="background:#1B1B1B">

<div style="color:white" ><h1>医院名称  患者姓名  检查类型</h1></div>

<div id="scrollDiv">
	<div class="scrollText">
	  <div class="box"></div>
	  <ul>
		<li>一脉阳光医学信息技术有限公司</li>
		<li>截止当前患者检查实时数据显示</li>
	  </ul>
	</div>
</div>

<script type="text/javascript" src="List.js"></script>

</body>
</html>
