
$(document).ready(function(){

	$("#scrollDiv").textSlider({line:1,speed:500,timer:2000});

});

$(document).ready(function(){
	function request(){
		$.ajax({
			type:'GET',
		url:'./Data.json',
		success:function(result){
			if(result.length <= 0){
				autoPlay();
				$("#scrollDiv ul li").text("该时段无影像");
			}else{
				console.log("aaa");
				for (x in result){
					for (var i=0; i<result[x].length; i++){
						$("#scrollDiv ul").append('<li>'+ result[x][i].PATIENT_NAME + '~~~ ' + result[x][i].PATIENT_ID + '~~~' +result[x][i].PATIENT_AGE1 +'</li>');
					}
				}
			}
		},
		})
	} 

	//每秒请求一次
	// setInterval(function(){
	//   request()},10000);
});
