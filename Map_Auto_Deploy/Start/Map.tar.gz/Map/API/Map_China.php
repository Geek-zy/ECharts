<?php
	$dir = dirname('__FILE__');
	require_once("$dir/Mysql_China.php");
	
	$Query = new Infor;
	$queryter = array('1' => '第一季度' ,
						'2' => '第二季度',
						'3' => '第三季度',
						'4' => '第四季度'
 		 );
	$type = array(
					'0' => '远程会诊',
					'1' => '共建影像中心',
					'2' => '独立影像中心',
					'3' => '云服务'
  		);
//	$_GET['year'] = 2016;
	$Hospital = array();
	$SumList = array();
	if(!empty($_GET['year'])){
		foreach($queryter as $mon => $month) {
			foreach($type as $key => $value) {
					$Array = $Query->queryData($_GET['year'],$mon,$key);
					$Size = number_format($Array[0]['Size'],2,'.','');
					$Information = array(
						$month => array(
									$value => array(
											'Count' => $Array[0]['Count'],
											'Size' => $Size
								)
							)
						);
				$Hospital = array_merge_recursive($Hospital,$Information);

			}
		}
		foreach ($type as $key => $value) {
				$sum = $Query->sum($_GET['year'],$key);
				// echo $sum[0]['SumSize'];exit;
				$TEMP = array(
					$value => array(
						'SumCount' => $sum[0]['SumCount'],
						'SumSize' =>  number_format($sum[0]['SumSize'],2,'.','')
					)
				);
					//array_push($SumList, $TEMP);
				$SumList = array_merge($SumList,$TEMP);
		}

	}else{

		return null;
	}
$SumList =array("全年统计" => $SumList);
$result = array_merge($Hospital,$SumList);
echo json_encode($result);
?>
