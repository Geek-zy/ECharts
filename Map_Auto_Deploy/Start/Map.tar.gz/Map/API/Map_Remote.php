<?php
	
	$dir = dirname('__FILE__');
	require_once("$dir/Mysql_Remote.php");

	$Infor = new Infor;
	$Data = $Infor->QueryHospital();
	$OneArray = array();
	$TwoArray = array();
	$ThreeArray = array();

	foreach ($Data as $k => $v) {	
		
		$OneArray[$v['app_id']] = array();
	}

	foreach ($Data as $k => $v) {
		foreach ($OneArray as $key => $value) {
			if($key==$v['app_id']){
				$OneArray[$key][$v['expert_id']]=$v;
			}
		}
		
	}
echo json_encode($OneArray,true);	
