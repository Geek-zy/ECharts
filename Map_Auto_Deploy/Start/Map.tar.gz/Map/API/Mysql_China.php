<?php
	class Infor
	{
		public $dbhost = '127.0.0.1';
		public $dbname = 'rimag_show';
		public $dbuser = 'root';
		public $password = 'root';
		
		/*
			init mysql connection
		*/
		function __construct(){
			try {
			$pdo = new PDO("mysql:host=$this->dbhost;dbname=$this->dbname",$this->dbuser,$this->password);
			}catch(PDOException $e){
				print "Error!: " . $e->getMessage() . "<br/>";
    			die();
			}
			$this->pdo = $pdo;
		}

		/*
			Query the usage of the 4 types of services
		*/
	 function queryData($year = "2016",$quarter = "1",$type = "0"){
			switch ($quarter) {
				case '1':
					$StarDate = $year . '-01' . '-01';
					$EndDate = $year . '-03' . '-01';
					break;
				case '2':
					$StarDate = $year . '-03' . '-01';
					$EndDate = $year . '-06' . '-01';
					break;
				case '3':
					$StarDate = $year . '-06' .'-01';
					$EndDate = $year . '-09' .'-01';
					break;
				default:
					$StarDate = $year . '-09' . '-01';
					$EndDate = $year . '-12' . '-01';
 					break;
			}
			
				$sql = "select sum(storage_data.patient_count) as Count,sum(storage_data.patient_size) as Size from storage_data INNER join hospital_client on hospital_client.hospital_id=storage_data.hospital_fk where hospital_client.type='".$type."' and storage_data.date BETWEEN '".$StarDate."' and '".$EndDate."'";
					//$this->sql = $sql;
					//echo $this->sql;
					$stmt = $this->pdo;
					$stmt =$stmt->prepare("$sql");
					$stmt->execute();
					$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
					//print_r($result);
					return $result;
			

		}
		function sum($year = "2016",$type = "0"){
			$begin_time = $year . "-01" . "-01";
			$end_time = $year . "-12" . "-01";
			$sql = "select sum(storage_data.patient_count) as SumCount,sum(storage_data.patient_size) as SumSize from storage_data INNER join hospital_client on hospital_client.hospital_id=storage_data.hospital_fk
			    where hospital_client.type='".$type."' 
			    and 
			    storage_data.date BETWEEN
			   '".$begin_time."' and '".$end_time."'";
			   $stmt = $this->pdo;
			   $stmt =$stmt->prepare("$sql");
			   $stmt->execute();
			   $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
			   return $result;
		}
	}
	
