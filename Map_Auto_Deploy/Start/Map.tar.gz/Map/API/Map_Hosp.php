<?php
	$dir = dirname('__FILE__');
	require_once("$dir/Mysql_Hosp.php");
	
	$Query = new Infor;
	$Data = $Query->Storage();
	$hospital_id = array_column($Data,'id');
	$Infor = array_combine($hospital_id,$Data);
foreach ($Infor as $key => $value) {
	$Infor[$key]['patientsize'] =  number_format($value['patientsize'],2,'.','');
}
	echo json_encode($Infor);
