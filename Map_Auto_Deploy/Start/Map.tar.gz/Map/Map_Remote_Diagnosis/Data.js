
var myDate = new Date();
var Date_Time = myDate.getFullYear() - 1;
var Date_Time_16 = Date_Time + 1;

var Json_Data;

function GET_Json_Data() {

	$.ajax({

		url:"../API/Map_Remote.php",
		type:"get",
		async:false,
		dataType:"json",

	success:function(data){

		Json_Data = data;
	},  

	error:function(data){

		console.log(data);
	}   
	}); 
}

GET_Json_Data();

// 二附院发起总数
var Data_2 = Json_Data[2][1].tcount;
// 二附院 ==> 一附院
var Data_2_1 = Json_Data[2][1].total;
// 二附院 ==> 天坛普华
var Data_2_13 = Json_Data[2][13].total;
//二附院 ==> 北京清华长庚医院
var Data_2_55 = Json_Data[2][55].total;
//二附院 ==> 首都医科大学附属北京安贞医院
var Data_2_56 = Json_Data[2][56].total;
//二附院 ==> 天坛医院
var Data_2_59 = Json_Data[2][59].total;
//二附院 ==>北京医院
var Data_2_62 = Json_Data[2][62].total;
//二附院 ==> 中国人民解放军总医院
var Data_2_89 = Json_Data[2][89].total;
//二附院 ==> 首都儿科研究所附属儿童医院
var Data_2_158 = Json_Data[2][158].total;

/*-------------------------------------------*/
//分宜县人民医院发起总数
var Data_8 = Json_Data[8][1].tcount;

//分宜　==>一附院
var Data_8_1 = Json_Data[8][1].total;
//分宜 ==>二附院
var Data_8_2 = Json_Data[8][2].total;
//分宜 ==>江西省肿瘤医院
var Data_8_3 = Json_Data[8][3].total;
//分宜 ==>北京清华长庚医院
var Data_8_55 = Json_Data[8][55].total;
//分宜 ==> 首都医科大学附属北京安贞医院
var Data_8_56 = Json_Data[8][56].total;
//分宜 ==>北京协和医院
var Data_8_58 = Json_Data[8][58].total;
//分宜 ==>首都医科大学附属北京友谊医院
var Data_8_60 = Json_Data[8][60].total;
//分宜 ==>北京医院
var Data_8_62 = Json_Data[8][62].total;
//分宜 ==>中国人民解放军总医院
var Data_8_89 = Json_Data[8][89].total;
//分宜 ==>上海长征医院
var Data_8_93 = Json_Data[8][93].total;
//分宜 ==>上海交通大学附属胸科医院
var Data_8_124 = Json_Data[8][124].total;
/*-----------------------------*/

//铅山县人民医院发起总数
var Data_14 = Json_Data[14][1].tcount;
//铅山 ==>南昌大学第一附属医院
var Data_14_1 = Json_Data[14][1].total;
//铅山县人民医院 ==>南昌大学第二附属医院
var Data_14_2 = Json_Data[14][2].total;
//铅山　==>首都医科大学附属北京安贞医院
var Data_14_56 = Json_Data[14][56].total;
/*---------------------------*/
//乐安县人民医院发起总数
var Data_15 = Json_Data[15][1].tcount;
//乐安县人民医院 ==>南昌大学第二附属医院
var Data_15_2 = Json_Data[15][2].total;
//乐安县人民医院 ==>江西省人民医院
var Data_15_5 = Json_Data[15][5].total;
//乐安县人民医院 ==>首都医科大学附属北京安贞医院
var Data_15_56 = Json_Data[15][56].total;
//乐安县人民医院 ==>北京中医药大学附属东方医院
var Data_15_156 = Json_Data[15][156].total;

/*------------------------*/
//宜春市中医院发起总数
var Data_16 = Json_Data[16][1].tcount;
//宜春市中医院 ==>南昌大学第一附属医院
var Data_16_1 = Json_Data[16][1].total;
//宜春市中医院 ==>南昌大学第二附属医院
var Data_16_2 = Json_Data[16][2].total;
//宜春市中医院 ==>江西省人民医院
var Data_16_5 = Json_Data[16][5].total;
//宜春市中医院 ==>北京清华长庚医院
var Data_16_55 = Json_Data[16][55].total;
//宜春市中医院 ==>首都医科大学附属北京安贞医院
var Data_16_56 = Json_Data[16][56].total;
//宜春市中医院 ==>首都医科大学附属北京天坛医院
var Data_16_59 = Json_Data[16][59].total;
/*-------------------------*/
//永丰县人民医院发起的总数
var Data_19 = Json_Data[19][1].tcount;
//永丰县人民医院 ==> 南昌大学第一附属医院
var Data_19_1 = Json_Data[19][1].total;
//永丰县人民医院 ==>南昌大学第二附属医院
var Data_19_2 = Json_Data[19][2].total;
//永丰县人民医院 ==>江西省人民医院
var Data_19_5 = Json_Data[19][5].total;
//永丰县人民医院 ==>首都医科大学附属北京安贞医院
var Data_19_56 = Json_Data[19][56].total;
/*-----------------------*/
//信丰县人民医院发起总数
var Data_20 = Json_Data[20][2].tcount;
//信丰县人民医院 ==>南昌大学第二附属医院
var Data_20_2 = Json_Data[20][2].total;
//信丰县人民医院 ==>首都医科大学附属北京安贞医院
var Data_20_56 = Json_Data[20][56].total;
/*----------------------*/
//上高县中医院发起总数
var Data_21 = Json_Data[21][1].tcount;
//上高县中医院 ==>南昌大学第一附属医院
var Data_21_1 = Json_Data[21][1].total;
//上高县中医院 ==>南昌大学第二附属医院
var Data_21_2 = Json_Data[21][2].total;
//上高县中医院 ==>北京清华长庚医院
var Data_21_55 = Json_Data[21][55].total;
//上高县中医院 ==>首都医科大学附属北京安贞医院
var Data_21_56 = Json_Data[21][56].total;
//上高县中医院 ==>北京协和医院
var Data_21_58 = Json_Data[21][58].total;
//上高县中医院 ==>首都医科大学附属北京天坛医院
var Data_21_59 = Json_Data[21][59].total;
//上高县中医院 ==>首都医科大学附属北京友谊医院
var Data_21_60 = Json_Data[21][60].total;
//上高县中医院 ==>中国人民解放军总医院
var Data_21_89 = Json_Data[21][89].total;
//上高县中医院 ==>复旦大学附属华山医院
var Data_21_91 = Json_Data[21][91].total;
//上高县中医院 ==>上海长征医院
var Data_21_93 = Json_Data[21][93].total;
//上高县中医院 ==>首都儿科研究所附属儿童医院
var Data_21_158 = Json_Data[21][158].total;
/*----------------------*/
//九江学院附属医院发起总数
var Data_22 = Json_Data[22][2].tcount;
//九江学院附属医院 ==>南昌大学第二附属医院
var Data_22_2 = Json_Data[22][2].total;
//九江学院附属医院 ==>首都医科大学附属北京安贞医院
var Data_22_56 = Json_Data[22][56].total;
//九江学院附属医院 ==>北京中医药大学附属东方医院
var Data_22_156 = Json_Data[22][156].total;
//九江学院附属医院 ==>首都儿科研究所附属儿童医院
var Data_22_158 = Json_Data[22][158].total;
/*--------------------*/
//江西省安福县人民医院发起总数
var Data_27 = Json_Data[27][1].tcount;
//江西省安福县人民医院 ==>南昌大学第一附属医院
var Data_27_1 = Json_Data[27][1].total;
//江西省安福县人民医院 ==>南昌大学第二附属医院
var Data_27_2 = Json_Data[27][2].total;
//江西省安福县人民医院 ==>首都医科大学附属北京安贞医院
var Data_27_56 = Json_Data[27][56].total;
//江西省安福县人民医院 ==>北京中医药大学附属东方医院
var Data_27_156 = Json_Data[27][156].total;
/*-----------------*/
//湖口县人民医院发起总数
var Data_28 = Json_Data[28][2].tcount;
//湖口县人民医院 ==>南昌大学第二附属医院
var Data_28_2 = Json_Data[28][2].total;
//湖口县人民医院 ==>首都医科大学附属北京安贞医院
var Data_28_56 = Json_Data[28][56].total;
//湖口县人民医院 ==>中国人民解放军总医院
var Data_28_89 = Json_Data[28][89].total;
//湖口县人民医院 ==>北京中医药大学附属东方医院
var Data_28_156 = Json_Data[28][156].total;
/*-------------------*/
//玉山县人民医院发起总数
var Data_29 = Json_Data[29][1].tcount;
//玉山县人民医院 ==>南昌大学第一附属医院
var Data_29_1 = Json_Data[29][1].total;
//玉山县人民医院 ==>南昌大学第二附属医院
var Data_29_2 = Json_Data[29][2].total;
//玉山县人民医院 ==>江西省人民医院
var Data_29_5 = Json_Data[29][5].total;
//玉山县人民医院 ==>首都医科大学附属北京安贞医院
var Data_29_56 = Json_Data[29][56].total;
//玉山县人民医院 ==>首都儿科研究所附属儿童医院
var Data_29_158 = Json_Data[29][158].total;
/*-------------------*/
//瑞金市人民医院发起总数
var Data_31 = Json_Data[31][1].tcount;
//瑞金市人民医院 ==>南昌大学第一附属医院
var Data_31_1 = Json_Data[31][1].total;
//瑞金市人民医院 ==>南昌大学第二附属医院
var Data_31_2 = Json_Data[31][2].total;
//瑞金市人民医院 ==>江西省人民医院
var Data_31_5 = Json_Data[31][5].total;
//瑞金市人民医院 ==>北京清华长庚医院
var Data_31_55 = Json_Data[31][55].total;
//瑞金市人民医院 ==>首都医科大学附属北京安贞医院
var Data_31_56 = Json_Data[31][56].total;
//瑞金市人民医院 ==>北京中医药大学附属东方医院
var Data_31_156 = Json_Data[31][156].total;
/*-------------------*/
//德兴市中医院发起总数
var Data_32 = Json_Data[32][1].tcount;
//德兴市中医院 ==>南昌大学第一附属医院
var Data_32_1 = Json_Data[32][1].total;
//德兴市中医院 ==>南昌大学第二附属医院
var Data_32_2 = Json_Data[32][2].total;
//德兴市中医院 ==>首都医科大学附属北京安贞医院
var Data_32_56 = Json_Data[32][56].total;
/*-------------------*/
//赣州市第五人民医院发起总数
var Data_33 = Json_Data[33][1].tcount;
//赣州市第五人民医院 ==>南昌大学第一附属医院
var Data_33_1 = Json_Data[33][1].total;
//赣州市第五人民医院 ==>南昌大学第二附属医院
var Data_33_2 = Json_Data[33][2].total;
//赣州市第五人民医院 ==>首都医科大学附属北京安贞医院
var Data_33_56 = Json_Data[33][56].total;
/*--------------------*/
//安远县人民医院发起总数
var Data_34 = Json_Data[34][1].tcount;
//安远县人民医院 ==>南昌大学第一附属医院
var Data_34_1 = Json_Data[34][1].total;
//安远县人民医院 ==>南昌大学第二附属医院
var Data_34_2 = Json_Data[34][2].total;
//安远县人民医院 ==>江西省人民医院
var Data_34_5 = Json_Data[34][5].total;
//安远县人民医院 ==>北京清华长庚医院
var Data_34_55 = Json_Data[34][55].total;
//安远县人民医院 ==>首都医科大学附属北京同仁医院
var Data_34_63 = Json_Data[34][63].total;
//安远县人民医院 ==>第二军医大学附属长海医院
var Data_34_120 = Json_Data[34][120].total;
/*----------------------*/
//高安市中医院发起总数
var Data_40 = Json_Data[40][1].tcount;
//高安市中医院 ==>南昌大学第一附属医院
var Data_40_1 = Json_Data[40][1].total;
/*---------------------*/
//广丰县人民医院发起总数
var Data_41 = Json_Data[41][1].tcount;
//广丰县人民医院 ==>南昌大学第一附属医院
var Data_41_1 = Json_Data[41][1].total;
//广丰县人民医院 ==>南昌大学第二附属医院
var Data_41_2 = Json_Data[41][2].total;
/*------------------*/
//江西省余干县中医院发起总数
var Data_44 = Json_Data[44][1].tcount;
//江西省余干县中医院 ==>南昌大学第一附属医院
var Data_44_1 = Json_Data[44][1].total;
//江西省余干县中医院 ==>南昌大学第二附属医院
var Data_44_2 = Json_Data[44][2].total;
//江西省余干县中医院 ==>江西省人民医院
var Data_44_5 = Json_Data[44][5].total;
//江西省余干县中医院 ==>首都医科大学附属北京安贞医院
var Data_44_56 = Json_Data[44][56].total;
//江西省余干县中医院 ==>北京中医药大学附属东方医院
var Data_44_156 = Json_Data[44][156].total;
/*--------------------*/
//江西省余干楚东医院发起总数
var Data_44 = Json_Data[44][1].tcount;
//江西省余干楚东医院 ==>南昌大学第一附属医院
var Data_45_1 = Json_Data[45][1].total;
//江西省余干楚东医院 ==>南昌大学第二附属医院
var Data_45_2 = Json_Data[45][2].total;
/*---------------------*/
//万安县人民医院发起总数
var Data_47 = Json_Data[47][1].tcount;
//万安县人民医院 ==>南昌大学第一附属医院
var Data_47_1 = Json_Data[47][1].total;
//万安县人民医院 ==>南昌大学第二附属医院
var Data_47_2 = Json_Data[47][2].total;
//万安县人民医院 ==>首都医科大学附属北京安贞医院
var Data_47_56 = Json_Data[47][56].total;
//万安县人民医院 ==>北京中医药大学附属东方医院
var Data_47_156 = Json_Data[47][156].total;
/*-------------------*/
//万安县中医院发起总数
var Data_48 = Json_Data[48][1].tcount;
//万安县中医院 ==>南昌大学第一附属医院
var Data_48_1 = Json_Data[48][1].total;
//万安县中医院 ==>南昌大学第二附属医院
var Data_48_2 = Json_Data[48][2].total;
//万安县中医院 ==>首都医科大学附属北京安贞医院
var Data_48_56 = Json_Data[48][56].total;
/*------------------*/
//南昌进贤中医院发起总数
var Data_49 = Json_Data[49][1].tcount;
//南昌进贤中医院 ==>南昌大学第一附属医院
var Data_49_1 = Json_Data[49][1].total;
//南昌进贤中医院 ==>南昌大学第二附属医院
var Data_49_2 = Json_Data[49][2].total;
/*-----------------*/
//上饶县人民医院发起总数
var Data_50 = Json_Data[50][1].tcount;
//上饶县人民医院 ==>南昌大学第一附属医院
var Data_50_1 = Json_Data[50][1].total;
//上饶县人民医院 ==>南昌大学第二附属医院
var Data_50_2 = Json_Data[50][2].total;
//上饶县人民医院 ==>首都医科大学附属北京安贞医院
var Data_50_56 = Json_Data[50][56].total;
/*----------------*/
//南昌市新建县人民医院发起总数
var Data_51 = Json_Data[51][1].tcount;
//南昌市新建县人民医院 ==>南昌大学第一附属医院
var Data_51_1 = Json_Data[51][1].total;
//南昌市新建县人民医院 ==>南昌大学第二附属医院
var Data_51_2 = Json_Data[51][2].total;
/*-----------------*/
//江西南丰县人民医院发起总数
var Data_52 = Json_Data[52][1].tcount;
//江西南丰县人民医院 ==>南昌大学第一附属医院
var Data_52_1 = Json_Data[52][1].total;
//江西南丰县人民医院 ==>南昌大学第二附属医院
var Data_52_2 = Json_Data[52][2].total;
//江西南丰县人民医院 ==>江西省人民医院
var Data_52_5 = Json_Data[52][5].total;
//江西南丰县人民医院 ==>首都医科大学附属北京安贞医院
var Data_52_56 = Json_Data[52][56].total;
//江西南丰县人民医院 ==>首都儿科研究所附属儿童医院
var Data_52_158 = Json_Data[52][158].total;
/*----------------*/
//赣州寻乌人民医院发起总数
var Data_54 = Json_Data[54][1].tcount;
//赣州寻乌人民医院 ==>南昌大学第一附属医院
var Data_54_1 = Json_Data[54][1].total;
//赣州寻乌人民医院 ==>南昌大学第二附属医院
var Data_54_2 = Json_Data[54][2].total;
//赣州寻乌人民医院 ==>江西省人民医院
var Data_54_5 = Json_Data[54][5].total;
//赣州寻乌人民医院 ==>首都医科大学附属北京安贞医院
var Data_54_56 = Json_Data[54][56].total;
//赣州寻乌人民医院 ==>北京中医药大学附属东方医院
var Data_54_156 = Json_Data[54][156].total;
/*-------------------*/
//永丰县中医院发起总数
var Data_67 = Json_Data[67][1].tcount;
//永丰县中医院 ==>南昌大学第一附属医院
var Data_67_1 = Json_Data[67][1].total;
//永丰县中医院 ==>南昌大学第二附属医院
var Data_67_2 = Json_Data[67][2].total;
//永丰县中医院 ==>江西省人民医院
var Data_67_5 = Json_Data[67][5].total;
/*------------------*/
//会昌县人民医院发起总数
var Data_72 = Json_Data[72][56].tcount;
//会昌县人民医院 ==>首都医科大学附属北京安贞医院
var Data_72_56 = Json_Data[72][56].tcount;
/*------------------*/
//修水中医院发起总数
var Data_73 = Json_Data[73][1].tcount;
//修水中医院 ==>南昌大学第一附属医院
var Data_73_1 = Json_Data[73][1].total;
//修水中医院 ==>首都医科大学附属北京安贞医院
var Data_73_56 = Json_Data[73][56].total;
/*------------------*/
//北京房山中医院发起总数
var Data_74 = Json_Data[74][55].tcount;
//北京房山中医院 ==>北京清华长庚医院
var Data_74_55 = Json_Data[74][55].total;
//北京房山中医院 ==>首都医科大学附属北京安贞医院
var Data_74_56 = Json_Data[74][56].total;
//北京房山中医院 ==>北京协和医院
var Data_74_58 = Json_Data[74][58].total;
//北京房山中医院 ==>首都医科大学附属北京天坛医院
var Data_74_59 = Json_Data[74][59].total;
//北京房山中医院 ==>首都医科大学附属北京友谊医院
var Data_74_60 = Json_Data[74][60].total;
//北京房山中医院 ==>首都医科大学附属北京同仁医院
var Data_74_63 = Json_Data[74][63].total;
//北京房山中医院 ==>中国人民解放军总医院
var Data_74_89 = Json_Data[74][89].total;
/*------------------*/
//鄱阳县人民医院发起总数
var Data_76 = Json_Data[76][1].tcount;
//鄱阳县人民医院 ==>南昌大学第一附属医院
var Data_76_1 = Json_Data[76][1].total;
//鄱阳县人民医院 ==>南昌大学第二附属医院
var Data_76_2 = Json_Data[76][2].total;
//鄱阳县人民医院 ==>江西省人民医院
var Data_76_5 = Json_Data[76][5].total;
//鄱阳县人民医院 ==>首都医科大学附属北京安贞医院
var Data_76_56 = Json_Data[76][56].total;
//鄱阳县人民医院 ==>北京中医药大学附属东方医院
var Data_76_156 = Json_Data[76][156].total;
//鄱阳县人民医院 ==>首都儿科研究所附属儿童医院
var Data_76_158 = Json_Data[76][158].total;
/*-----------------*/
//余江县人民医院发起总数
var Data_79 = Json_Data[79][1].tcount;
//余江县人民医院 ==>南昌大学第一附属医院
var Data_79_1 = Json_Data[79][1].total;
//余江县人民医院 ==>南昌大学第二附属医院
var Data_79_2 = Json_Data[79][2].total;
//余江县人民医院 ==>首都医科大学附属北京天坛医院
var Data_79_59 = Json_Data[79][59].total;
//余江县人民医院 ==>北京中医药大学附属东方医院
var Data_79_156 = Json_Data[79][156].total;
/*--------------------*/
//海拉尔农垦总医院发起总数
var Data_81 = Json_Data[81][55].tcount;
//海拉尔农垦总医院 ==>北京清华长庚医院
var Data_81_55 = Json_Data[81][55].total;
//海拉尔农垦总医院 ==>首都医科大学附属北京安贞医院
var Data_81_56 = Json_Data[81][56].total;
//海拉尔农垦总医院 ==>北京协和医院
var Data_81_58 = Json_Data[81][58].total;
//海拉尔农垦总医院 ==>首都医科大学附属北京天坛医院
var Data_81_59 = Json_Data[81][59].total;
//海拉尔农垦总医院 ==>首都医科大学附属北京友谊医院
var Data_81_60 = Json_Data[81][60].total;
//海拉尔农垦总医院 ==>首都医科大学附属北京同仁医院
var Data_81_63 = Json_Data[81][63].total;
//海拉尔农垦总医院 ==>中国人民解放军总医院
var Data_81_89 = Json_Data[81][89].total;
//海拉尔农垦总医院 ==>北京中医药大学附属东方医院
var Data_81_156 = Json_Data[81][156].total;
/*-----------------*/
//库伦旗医院发起总数
var Data_83 = Json_Data[83][56].tcount;
//库伦旗医院 ==>首都医科大学附属北京安贞医院
var Data_83_56 = Json_Data[83][56].total;
/*-----------------*/
//景德镇第二人民医院发起总数
var Data_86 = Json_Data[86][1].tcount;
//景德镇第二人民医院 ==>南昌大学第一附属医院
var Data_86_1 = Json_Data[86][1].total;
//景德镇第二人民医院 ==>中国人民解放军总医院
var Data_86_89 = Json_Data[86][89].total;
/*------------------*/
//分宜县洞村乡卫生院发起总数
var Data_100 = Json_Data[100][8].tcount;
//分宜县洞村乡卫生院 ==>分宜县人民医院
var Data_100_8 = Json_Data[100][8].total;
/*-----------------*/
//彭泽县人民医院发起总数
var Data_108 = Json_Data[108][2].tcount;
//彭泽县人民医院 ==>南昌大学第二附属医院
var Data_108_2 = Json_Data[108][2].total;
//彭泽县人民医院 ==>首都医科大学附属北京安贞医院
var Data_108_56 = Json_Data[108][56].total;
/*-----------------*/
//万年县人民医院发起总数
var Data_109 = Json_Data[109][56].tcount;
//万年县人民医院 ==>首都医科大学附属北京安贞医院
var Data_109_56 = Json_Data[109][56].total;
//万年县人民医院 ==>首都儿科研究所附属儿童医院
var Data_109_158 = Json_Data[109][158].total;
/*--------------------*/
//分宜县操场乡卫生院发起总数
var Data_110 = Json_Data[110][8].tcount;
//分宜县操场乡卫生院 ==>分宜县人民医院
var Data_110_8 = Json_Data[110][8].total;
/*--------------------*/
//九江县人民医院发起总数
var Data_112 = Json_Data[112][1].tcount;
//九江县人民医院 ==>南昌大学第一附属医院
var Data_112_1 = Json_Data[112][1].total;
//万年县中医院发起总数
var Data_113 = Json_Data[113][2].tcount;
//万年县中医院 ==>南昌大学第二附属医院
var Data_113_2 = Json_Data[113][2].total;
/*-----------------*/
//内蒙古赤峰松山医院发起总数
var Data_114 = Json_Data[114][56].tcount;
//内蒙古赤峰松山医院 ==>首都医科大学附属北京安贞医院
var Data_114_56 = Json_Data[114][56].total;
//内蒙古赤峰松山医院 ==>首都医科大学附属北京天坛医院
var Data_114_59 = Json_Data[114][59].total;
//内蒙古赤峰松山医院 ==>北京中医药大学附属东方医院
var Data_114_156 = Json_Data[114][156].total;
/*-----------------*/
//崇仁县人民医院发起总数
var Data_115 = Json_Data[115][2].tcount;
//崇仁县人民医院 ==>南昌大学第二附属医院
var Data_115_2 = Json_Data[115][2].total;
//崇仁县人民医院 ==>首都医科大学附属北京安贞医院
var Data_115_56 = Json_Data[115][56].total;
//崇仁县人民医院 ==>北京中医药大学附属东方医院
var Data_115_156 = Json_Data[115][156].total;
/*----------------*/
//分宜县双林镇卫生院发起总数
var Data_119 = Json_Data[119][8].tcount;
//分宜县双林镇卫生院 ==>分宜县人民医院
var Data_119_8 = Json_Data[119][8].total;
/*------------------*/
//吉安县中医院发起总数
var Data_121 = Json_Data[121][1].tcount;
//吉安县中医院 ==>南昌大学第一附属医院
var Data_121_1 = Json_Data[121][1].total;
//吉安县中医院 ==>南昌大学第二附属医院
var Data_121_2 = Json_Data[121][2].total;
//吉安县中医院 ==>首都医科大学附属北京安贞医院
var Data_121_56 = Json_Data[121][56].total;
/*-------------------*/
//赤峰市巴林左旗医院发起总数
var Data_123 = Json_Data[123][56].tcount;
//赤峰市巴林左旗医院 ==>首都医科大学附属北京安贞医院
var Data_123_56 = Json_Data[123][56].total;
/*-------------------*/
//兴国县人民医院发起总数
var Data_137 = Json_Data[137][56].tcount;
//兴国县人民医院 ==>首都医科大学附属北京安贞医院
var Data_137_56 = Json_Data[137][56].total;
//兴国县人民医院 ==>首都儿科研究所附属儿童医院
var Data_137_158 = Json_Data[137][158].total;
/*------------------*/
//兴国县鼎龙卫生院发起总数
var Data_146 = Json_Data[146][137].tcount;
//兴国县鼎龙卫生院 ==>兴国县人民医院
var Data_146_137 = Json_Data[146][137].total;
/*------------------*/
//瑞昌市人民医院发起总数
var Data_152 = Json_Data[152][2].tcount;
//瑞昌市人民医院 ==>南昌大学第二附属医院
var Data_152_2 = Json_Data[152][2].total;
/*-----------------*/
//永新县中医院发起总数
var Data_157 = Json_Data[157][1].tcount;
//永新县中医院 ==>南昌大学第一附属医院
var Data_157_1 = Json_Data[157][1].total;
//永新县中医院 ==>首都医科大学附属北京安贞医院
var Data_157_56 = Json_Data[157][56].total;
/*-------------------*/
//内蒙古赤峰松山中蒙医院发起总数
var Data_159 = Json_Data[159][56].tcount;
//内蒙古赤峰松山中蒙医院 ==>首都医科大学附属北京安贞医院
var Data_159_56 = Json_Data[159][56].total;
/*------------------*/
//荆门市第二人民医院发起总数
var Data_160 = Json_Data[160][2].tcount;
//荆门市第二人民医院 ==>南昌大学第二附属医院
var Data_160_2 = Json_Data[160][2].total;
//荆门市第二人民医院 ==>首都医科大学附属北京安贞医院
var Data_160_56 = Json_Data[160][56].total;
//荆门市第二人民医院 ==>中国人民解放军总医院
var Data_160_89 = Json_Data[160][89].total;
//荆门市第二人民医院 ==>第二军医大学附属长海医院
var Data_160_120 = Json_Data[160][120].total;
//荆门市第二人民医院 ==>北京大学第一医院
var Data_160_149 = Json_Data[160][149].total;
/*--------------------*/
//惠民县妇幼保健医院发起总数
var Data_164 = Json_Data[164][56].tcount;
//惠民县妇幼保健医院 ==>首都医科大学附属北京安贞医院
var Data_164_56 = Json_Data[164][56].total;
//惠民县妇幼保健医院 ==>山东省千佛山医院
var Data_164_166 = Json_Data[164][166].total;
/*--------------------*/
//广丰县南方医院发起总数
var Data_173 = Json_Data[173][56].tcount;
//广丰县南方医院 ==>首都医科大学附属北京安贞医院
var Data_173_56 = Json_Data[173][56].total;
/*------------------*/
//赣州市肿瘤医院发起总数
var Data_177 = Json_Data[177][56].tcount;
//赣州市肿瘤医院 ==>首都医科大学附属北京安贞医院
var Data_177_56 = Json_Data[177][56].total;
/*------------------*/
//内蒙古五原县人民医院发起总数
var Data_180 = Json_Data[180][56].tcount;
//内蒙古五原县人民医院 ==>首都医科大学附属北京安贞医院
var Data_180_56 = Json_Data[180][56].total;
/*-----------------*/
//永修县人民医院发起总数
var Data_181 = Json_Data[181][56].tcount;
//永修县人民医院 ==>首都医科大学附属北京安贞医院
var Data_181_56 = Json_Data[181][56].total;
/*------------------*/
//石城县人民医院发起总数
var Data_182 = Json_Data[182][1].tcount;
//石城县人民医院 ==>南昌大学第一附属医院
var Data_182_1 = Json_Data[182][1].total;
//石城县人民医院 ==>南昌大学第二附属医院
var Data_182_2 = Json_Data[182][2].total;
/*-----------------*/
//瑞昌市中医院发起总数
var Data_184 = Json_Data[184][1].tcount;
//瑞昌市中医院 ==>南昌大学第一附属医院
var Data_184_1 = Json_Data[184][1].total;
//瑞昌市中医院 ==>首都医科大学附属北京安贞医院
var Data_184_56 = Json_Data[184][56].total;
/*------------------*/
//平度城区医院发起总数
var Data_187 = Json_Data[187][56].tcount;
//平度城区医院 ==>首都医科大学附属北京安贞医院
var Data_187_56 = Json_Data[187][56].total;
/*--------------------*/
//烟台龙矿中心医院发起总数
var Data_188 = Json_Data[188][56].tcount;
//烟台龙矿中心医院 ==>首都医科大学附属北京安贞医院
var Data_188_56 = Json_Data[188][56].total;
/*------------------*/
//湖口县中医院发起总数
var Data_199 = Json_Data[199][22].tcount;
//湖口县中医院 ==>九江学院附属医院
var Data_199_22 = Json_Data[199][22].total;

require.config({
	paths: {
		//echarts: 'http://echarts.baidu.com/build/dist'
		echarts: '../Echarts'
	}
});

require (

			[
			'echarts',
			'echarts/chart/map'
			],

			function (ec) {
				var myChart = ec.init(document.getElementById('main'));

				myChart.setOption(option);
			}
		);
