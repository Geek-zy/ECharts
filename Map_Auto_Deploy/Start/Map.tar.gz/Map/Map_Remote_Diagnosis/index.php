<!DOCTYPE html>

<html>

<head>
	<meta charset="utf-8">
	<title>一脉阳光远程会诊分线图</title>
</head>

	<body style="background:#1B1B1B">  

	<div id="main" style="height:800px"></div>
	<script type="text/javascript" src="../Echarts/jquery-1.8.0.js"></script>
	<script type="text/javascript" src="../Echarts/echarts.js"></script>
	<!--script src="http://echarts.baidu.com/build/dist/echarts.js"></script-->
	<script type="text/javascript" src="Data.js"></script>
	<script type="text/javascript" src="Map.js"></script>
  
	</body>  
</html>
