
var myDate = new Date();
var Date_Time = myDate.getFullYear() - 1;

var Json_Data;

function GET_Json_Data() {

	    $.ajax({

			url:"../../../API/Map_Hosp.php",
		type:"get",
		async:false,
		dataType:"json",

		success:function(data){

			Json_Data = data;
		},

		error:function(data){

			console.log(data);
		}
		});
}

GET_Json_Data();
//海拉尔农垦总医院
var Data_81 = Json_Data[81].patientcount;
////八仙筒镇卫生院
var Data_82 = Json_Data[82].patientcount;
////库伦旗医院
var Data_83 = Json_Data[83].patientcount;
////通辽市精神卫生中心
var Data_107 = Json_Data[107].patientcount;
////内蒙古赤峰松山医院
var Data_121 = Json_Data[121].patientcount;
////赤峰市巴林左旗医院
var Data_123 = Json_Data[123].patientcount;
//内蒙古赤峰松山中蒙医院
var Data_159 = Json_Data[159].patientcount;
//通辽市传染病医院
var Data_161 = Json_Data[161].patientcount;
////科左中旗中医院
var Data_162 = Json_Data[162].patientcount;
//内蒙古通辽市保康蒙医院
var Data_167 = Json_Data[167].patientcount;
////巴彦淖尔市杭锦后旗同济医院
var Data_170 = Json_Data[170].patientcount;
////清水河县人民医院
var Data_171 = Json_Data[171].patientcount;
////土默特左旗人民医院
var Data_172 = Json_Data[172].patientcount;
////内蒙古五原县人民医院
var Data_180 = Json_Data[180].patientcount;
////察右后旗医院
var Data_190 = Json_Data[190].patientcount;

require.config({
	paths: {
		//echarts: 'http://echarts.baidu.com/build/dist'
		echarts: '../../../Echarts'
	}
});

require (

			[
			'echarts',
			'echarts/chart/map'
			],

			function (ec) {
				var myChart = ec.init(document.getElementById('main'));

				myChart.setOption(option);
			}
		);
