
option = {

	//标题及说明文字
	title : { 

		text: '一脉阳光 ' + Date_Time + '年内蒙古自治区患者影像例数',
		//subtext: "截止到：2016-11-10 12:00:00",
		x:'center',
		textStyle:{color:'red'}

	},  

	//显示弹框数据 圈和线的数据
	tooltip : { 

		trigger: 'item'
	}, 

	//左上角自定义按钮
	legend: {

		orient: 'vertical',
		x:'left',
		textStyle:{color:'red'},
		data:['北京','江西','湖北','山东','内蒙古']
	},

	//左下角数量标尺
	dataRange: {

		min : 0,
			max : 500,
			x: 'right',
			y: 'bottom',
			text:['高','低'],
			calculable : true,
			color: ['#ff3333', 'orange', 'yellow','lime','aqua'],
			textStyle:{color:'#fff'}
	}, 

	//右侧工具栏
/*	toolbox: {

		show: true,
		orient : 'vertical',
		x: 'right',
		y: 'center',

		feature : {
			mark : {show: true},
				 dataView : {show: true, readOnly: false},
				 restore : {show: true},
				 saveAsImage : {show: true}
		}
	},

	//右上角方位移动按钮
	roamController: {

		show: true,
		x: 'right',
		mapTypeControl: {'china': true}
	},
*/
	series : [
	{
		name: '内蒙古',
		type: 'map',
		mapType: '内蒙古',
		roam: true,
		hoverable: false, //地区高亮禁止
		itemStyle:{
			normal:{
				label:{show:true}, //地区显示名字
				borderColor:'rgba(100,149,237,1)',
				borderWidth:0.5,
				areaStyle:{color: '#1b1b1b'}
			}
		},
		data:[],
		markLine : {
			smooth:true,
			symbol: ['none', 'circle'],  
			symbolSize : 1,
			itemStyle : {
				normal: {
					color:'#fff',
					borderWidth:1,
					borderColor:'rgba(30,144,255,0.5)'
				}
			},
			data : [],
		},

	geoCoord: {
			'内蒙古影像中心':[114.41586754816612,43.46823822194904],
			'海拉尔农垦总医院':[119.74889787081258,49.23019572730968],
			'八仙筒镇卫生院':[121.04966552368795,43.21628532129702],
			'库伦旗医院':[121.77822813807718,42.73638639304407],
			'通辽市中医院':[122.26036326322144,43.633756072995986],
			'通辽市精神卫生中心':[122.28275828907684,43.62952522015156],
			'内蒙古赤峰松山医院':[118.93835133474359,42.284346320979026],
			'内蒙古赤峰松山中蒙医院':[118.93864539056075,42.28458207514079],
			'通辽市传染病医院':[122.280064025615,43.603033258057394],
			'科左中旗中医院':[null,null],
			'内蒙古通辽市保康蒙医院':[122.26036326322144,43.633756072995986],
			'巴彦淖尔市杭锦后旗同济医院':[107.15605612829046,40.89579849214696],
			'清水河县人民医院':[111.70623630690847,39.889117744684924],
			'土默特左旗人民医院':[111.15602024831864,40.73086344742712],
			'内蒙古五原县人民医院':[108.2804566299733,41.10446412165275],
			'察右后旗医院':[null,null],
			'内蒙赤峰市医院':[118.9307611921676,42.297112320317325],
			'赤峰市巴林左旗医院':[119.40150386130883,43.98478731065006],

	},

		markPoint : {

			symbol:'emptyCircle',
			symbolSize : function (v){

				return 10 + v/5000
			},

			effect : {

				show: true,
				shadowBlur : 0
			},

			itemStyle:{

				normal:{

					label:{show:false}
				},

				emphasis: {

					label:{position:'top'}
				}
			},

			//发光圈子，弹数据
			data : [

			{name:'海拉尔农垦总医院',value:Data_81},
			{name:'八仙筒镇卫生院',value:Data_82},
			{name:'库伦旗医院',value:Data_83},
			{name:'通辽市中医院',value:30},
			{name:'通辽市精神卫生中心',value:Data_107},
			{name:'内蒙古赤峰松山医院',value:Data_121},
			{name:'内蒙古赤峰松山中蒙医院',value:Data_159},
			{name:'赤峰市巴林左旗医院',value:Data_123},
			{name:'通辽市传染病医院',value:Data_161},
			{name:'科左中旗中医院',value:Data_162},
			{name:'内蒙古通辽市保康蒙医院',value:Data_167},
			{name:'巴彦淖尔市杭锦后旗同济医院',value:Data_170},
			{name:'清水河县人民医院',value:Data_171},
			{name:'土默特左旗人民医院',value:Data_172},
			{name:'内蒙古五原县人民医院',value:Data_180},
			{name:'察右后旗医院',value:Data_190},
			{name:'内蒙赤峰市医院',value:50},
			]
		

		}
	},

	//划线 ==> 北京
	{
		type: 'map',
		mapType: '内蒙古',
		data:[],
		markLine : {
			smooth:true,
			effect : {
				show: true,
				scaleSize: 1,
				period: 30,
				color: '#fff',
				shadowBlur: 10
			},
			itemStyle : {
				normal: {
					label:{show:false},
					borderWidth:1,
					lineStyle: {
						type: 'solid',
						shadowBlur: 10
					}
				}
			},

			data : []

		},

		//圈中的数据
		markPoint : {

			symbol:'emptyCircle',
			symbolSize : function (v){

				return 0.1
			},

			effect : {

				show: false,
				shadowBlur : 0
			},

			itemStyle:{

			nor:[],mal:{

					label:{

						show:true,
						position:'top',
						textStyle: {fontSize: 14}
					}
				},

				emphasis: {label:{show:false}}
			},

			data : [
			{name:'海拉尔农垦总医院',value:Data_81},
			{name:'八仙筒镇卫生院',value:Data_82},
			{name:'库伦旗医院',value:Data_83},
			{name:'通辽市中医院',value:30},
			{name:'通辽市精神卫生中心',value:Data_107},
			{name:'内蒙古赤峰松山医院',value:Data_121},
			{name:'内蒙古赤峰松山中蒙医院',value:Data_159},
			{name:'赤峰市巴林左旗医院',value:Data_123},
			{name:'通辽市传染病医院',value:Data_161},
			{name:'科左中旗中医院',value:Data_162},
			{name:'内蒙古通辽市保康蒙医院',value:Data_167},
			{name:'巴彦淖尔市杭锦后旗同济医院',value:Data_170},
			{name:'清水河县人民医院',value:Data_171},
			{name:'土默特左旗人民医院',value:Data_172},
			{name:'内蒙古五原县人民医院',value:Data_180},
			{name:'察右后旗医院',value:Data_190},
			{name:'内蒙赤峰市医院',value:50},

			]
		}
	}

	//------------------分割线-----------------
	//以上数据可拷贝增加自定义按钮
	]
}
