
option = {

	//标题及说明文字
	title : { 

		text: '一脉阳光 ' + Date_Time + '年湖北省患者影像例数',
		//subtext: "截止到：2016-11-10 12:00:00",
		x:'center',
		textStyle:{color:'red'}

	},  

	//显示弹框数据 圈和线的数据
	tooltip : { 

		trigger: 'item'
	}, 

	//左上角自定义按钮
	legend: {

		orient: 'vertical',
		x:'left',
		textStyle:{color:'red'},
		data:['北京','江西','湖北','山东','内蒙古']
	},

	//左下角数量标尺
	dataRange: {

		min : 0,
			max : 500,
			x: 'right',
			y: 'bottom',
			text:['高','低'],
			calculable : true,
			color: ['#ff3333', 'orange', 'yellow','lime','aqua'],
			textStyle:{color:'#fff'}
	}, 

	//右侧工具栏
	/*toolbox: {

		show: true,
		orient : 'vertical',
		x: 'right',
		y: 'center',

		feature : {
			mark : {show: true},
				 dataView : {show: true, readOnly: false},
				 restore : {show: true},
				 saveAsImage : {show: true}
		}
	},

	//右上角方位移动按钮
	roamController: {

		show: true,
		x: 'right',
		mapTypeControl: {'china': true}
	},
*/
	series : [
	{
		name: '湖北',
		type: 'map',
		mapType: '湖北',
		roam: true,
		hoverable: false, //地区高亮禁止
		itemStyle:{
			normal:{
				label:{show:true}, //地区显示名字
				borderColor:'rgba(100,149,237,1)',
				borderWidth:0.5,
				areaStyle:{color: '#1b1b1b'}
			}
		},
		data:[],
		markLine : {
			smooth:true,
			symbol: ['none', 'circle'],  
			symbolSize : 1,
			itemStyle : {
				normal: {
					color:'#fff',
					borderWidth:1,
					borderColor:'rgba(30,144,255,0.5)'
				}
			},
			data : [],
		},

	geoCoord: {
	
		'湖北影像管理中心':[112.41056219213213,31.209316250139747],
		'华中科技大学同济医学院附属同济医院':[114.26601646389192,30.587663505244805],
		'华中科技大学同济医学院附属协和医院':[114.26601646389192,30.587663505244805],
		'湖北省人民医院':[114.3037868679917,30.54105200870612],
		'黄石市中医院':[115.05068316392396,30.21612712771406],
		'黄石市中心医院':[115.11624060892308,30.209549647394763],
		'荆门市第二人民医院':[112.20557966699756,31.047591359149386],
		'宜城市中医院':[112.37274539500838,31.673335169944203],
	},

		markPoint : {

			symbol:'emptyCircle',
			symbolSize : function (v){

				return 10 + v/5000
			},

			effect : {

				show: true,
				shadowBlur : 0
			},

			itemStyle:{

				normal:{

					label:{show:false}
				},

				emphasis: {

					label:{position:'top'}
				}
			},

			//发光圈子，弹数据
			data : [

			{name:'荆门市第二人民医院',value:Data_160},
			]
		

		}
	},

	//划线 ==> 北京
	{
		type: 'map',
		mapType: '湖北',
		data:[],
		markLine : {
			smooth:true,
			effect : {
				show: true,
				scaleSize: 1,
				period: 30,
				color: '#fff',
				shadowBlur: 10
			},
			itemStyle : {
				normal: {
					label:{show:false},
					borderWidth:1,
					lineStyle: {
						type: 'solid',
						shadowBlur: 10
					}
				}
			},

			data : []

		},

		//圈中的数据
		markPoint : {

			symbol:'emptyCircle',
			symbolSize : function (v){

				return 0.1
			},

			effect : {

				show: false,
				shadowBlur : 0
			},

			itemStyle:{

			nor:[],mal:{

					label:{

						show:true,
						position:'top',
						textStyle: {fontSize: 14}
					}
				},

				emphasis: {label:{show:false}}
			},

			data : [
				{name:'荆门市第二人民医院',value:Data_160},
			]
		}
	}

	//------------------分割线-----------------
	//以上数据可拷贝增加自定义按钮
	]
}
