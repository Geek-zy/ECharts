
var myDate = new Date();
var Date_Time = myDate.getFullYear() - 1;

var Json_Data;

function GET_Json_Data() {

	    $.ajax({

			url:"../../../API/Map_Hosp.php",
		type:"get",
		async:false,
		dataType:"json",

		success:function(data){

			Json_Data = data;
		},

		error:function(data){

			console.log(data);
		}
		});
}
	GET_Json_Data();
	//进门二院
	var Data_160 = Json_Data[160].patientcount;

	require.config({
	paths: {
		//echarts: 'http://echarts.baidu.com/build/dist'
		echarts: '../../../Echarts'
	}
});


require (

			[
			'echarts',
			'echarts/chart/map'
			],

			function (ec) {
				var myChart = ec.init(document.getElementById('main'));

				myChart.setOption(option);
			}
		);
