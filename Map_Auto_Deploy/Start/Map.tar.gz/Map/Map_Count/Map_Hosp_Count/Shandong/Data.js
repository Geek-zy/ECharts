
var myDate = new Date();
var Date_Time = myDate.getFullYear() - 1;

var Json_Data;

function GET_Json_Data() {

	    $.ajax({

			url:"../../../API/Map_Hosp.php",
		type:"get",
		async:false,
		dataType:"json",

		success:function(data){

			Json_Data = data;
		},

		error:function(data){

			console.log(data);
		}
		});
}

GET_Json_Data();
//德州十三局医院
var Data_117 = Json_Data[117].patientcount;
//平度城区医院
var Data_187 = Json_Data[187].patientcount;
//烟台龙矿中心医院
 var Data_188 = Json_Data[188].patientcount;
 ////临沂市河东区人民医院
 var Data_193 = Json_Data[193].patientcount;

require.config({
	paths: {
		//echarts: 'http://echarts.baidu.com/build/dist'
		echarts: '../../../Echarts'
	}
});

require (

			[
			'echarts',
			'echarts/chart/map'
			],

			function (ec) {
				var myChart = ec.init(document.getElementById('main'));

				myChart.setOption(option);
			}
		);
