
option = {

	//标题及说明文字
	title : { 

		text: '一脉阳光 ' + Date_Time + '年山东省患者影像例数',
		//subtext: "截止到：2016-11-10 12:00:00",
		x:'center',
		textStyle:{color:'red'}

	},  

	//显示弹框数据 圈和线的数据
	tooltip : { 

		trigger: 'item'
	}, 

	//左上角自定义按钮
	legend: {

		orient: 'vertical',
		x:'left',
		textStyle:{color:'red'},
		data:['北京','江西','湖北','山东','内蒙古']
	},

   	//左下角数量标尺
	dataRange: {

		min : 0,
			max : 500,
			x: 'right',
			y: 'bottom',
			text:['高','低'],
			calculable : true,
			color: ['#ff3333', 'orange', 'yellow','lime','aqua'],
			textStyle:{color:'#fff'}
	}, 

	//右侧工具栏
	/*toolbox: {

		show: true,
		orient : 'vertical',
		x: 'right',
		y: 'center',

		feature : {
			mark : {show: true},
				 dataView : {show: true, readOnly: false},
				 restore : {show: true},
				 saveAsImage : {show: true}
		}
	},

	//右上角方位移动按钮
	roamController: {

		show: true,
		x: 'right',
		mapTypeControl: {'china': true}
	},
*/
	series : [
	{
		name: '山东',
		type: 'map',
		mapType: '山东',
		roam: true,
		hoverable: false, //地区高亮禁止
		itemStyle:{
			normal:{
				label:{show:true}, //地区显示名字
				borderColor:'rgba(100,149,237,1)',
				borderWidth:0.5,
				areaStyle:{color: '#1b1b1b'}
			}
		},
		data:[],
		markLine : {
			smooth:true,
			symbol: ['none', 'circle'],  
			symbolSize : 1,
			itemStyle : {
				normal: {
					color:'#fff',
					borderWidth:1,
					borderColor:'rgba(30,144,255,0.5)'
				}
			},
			data : [],
		},

	geoCoord: {
            '山东影像管理中心':[118.52766339287801,36.09928992972826],
			'山东省立医院':[116.9900318374478,36.66251038941924],
	        '德州十三局医院':[116.3166946653024,37.44957765511814],
	        '山东大学第二附属医院':[117.05619845395563,36.60925766517348],
	        '惠民县妇幼保健医院':[117.57898363783785,37.37597131845397],
	        '山东省医学影像研究所':[118.52766339287801,36.09928992972826],
	        '山东省千佛山医院':[117.0493000398596,36.65265675740564],
	        '山东大学齐鲁医院':[117.0252535413072,36.66180539421739],
			'平度城区医院':[119.9929975898305,36.79468223789339],
			'烟台龙矿中心医院':[120.33030922924996,37.63086663242046],
			'临沂市河东区人民医院':[118.40025571629567,35.08639661661979],		

	},

		markPoint : {

			symbol:'emptyCircle',
			symbolSize : function (v){

				return 10 + v/5000
			},

			effect : {

				show: true,
				shadowBlur : 0
			},

			itemStyle:{

				normal:{

					label:{show:false}
				},

				emphasis: {

					label:{position:'top'}
				}
			},

			//发光圈子，弹数据
			data : [

			{name:'临沂市河东区人民医院',value:Data_193},
			{name:'平度城区医院',value:Data_187},
			{name:'烟台龙矿中心医院',value:Data_188},
			{name:'德州十三局医院',value:Data_117},
			]
		

		}
	},

	//划线 ==> 北京
	{
		type: 'map',
		mapType: '山东',
		data:[],
		markLine : {
			smooth:true,
			effect : {
				show: true,
				scaleSize: 1,
				period: 30,
				color: '#fff',
				shadowBlur: 10
			},
			itemStyle : {
				normal: {
					label:{show:false},
					borderWidth:1,
					lineStyle: {
						type: 'solid',
						shadowBlur: 10
					}
				}
			},

			data : []

		},

		//圈中的数据
		markPoint : {

			symbol:'emptyCircle',
			symbolSize : function (v){

				return 0.1
			},

			effect : {

				show: false,
				shadowBlur : 0
			},

			itemStyle:{

			nor:[],mal:{

					label:{

						show:true,
						position:'top',
						textStyle: {fontSize: 14}
					}
				},

				emphasis: {label:{show:false}}
			},

			data : [
            {name:'临沂市河东区人民医院',value:Data_193},
			{name:'平度城区医院',value:Data_187},
			{name:'烟台龙矿中心医院',value:Data_188},
			{name:'德州十三局医院',value:Data_117},

			]
		}
	}

	//------------------分割线-----------------
	//以上数据可拷贝增加自定义按钮
	]
}
