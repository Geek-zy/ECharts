
var myDate = new Date();
var Date_Time = myDate.getFullYear() - 1;

var Json_Data;

function GET_Json_Data() {

	$.ajax({

		url:"../../API/Map_China.php?year=" + Date_Time,
		type:"get",
		async:false,
		dataType:"json",

		success:function(data){

			Json_Data = data;
		},
	
		error:function(data){
		
			console.log(data);
		}
	});
}

GET_Json_Data();
//console.log(Json_Data.第一季度.云服务.Count);

/*
All   ==>  全年统计
One   ==>  第一季度
Two	  ==>  第二季度
Three ==>  第三季度
Four  ==>  第四季度

0 ==> 远程会诊
1 ==> 共建影像中心
2 ==> 独立影像中心
3 ==> 云服务
*/

All_0 = Json_Data.全年统计.远程会诊.SumCount;
All_1 = Json_Data.全年统计.共建影像中心.SumCount;
All_2 = Json_Data.全年统计.独立影像中心.SumCount;
All_3 = Json_Data.全年统计.云服务.SumCount;

One_0 = Json_Data.第一季度.远程会诊.Count;
One_1 = Json_Data.第一季度.共建影像中心.Count;
One_2 = Json_Data.第一季度.独立影像中心.Count;
One_3 = Json_Data.第一季度.云服务.Count;

Two_0 = Json_Data.第二季度.远程会诊.Count;
Two_1 = Json_Data.第二季度.共建影像中心.Count;
Two_2 = Json_Data.第二季度.独立影像中心.Count;
Two_3 = Json_Data.第二季度.云服务.Count;

Three_0 = Json_Data.第三季度.远程会诊.Count;
Three_1 = Json_Data.第三季度.共建影像中心.Count;
Three_2 = Json_Data.第三季度.独立影像中心.Count;
Three_3 = Json_Data.第三季度.云服务.Count;

Four_0 = Json_Data.第四季度.远程会诊.Count;
Four_1 = Json_Data.第四季度.共建影像中心.Count;
Four_2 = Json_Data.第四季度.独立影像中心.Count;
Four_3 = Json_Data.第四季度.云服务.Count;

require.config({
	paths: {
		//echarts: 'http://echarts.baidu.com/build/dist'
		echarts: '../../Echarts'
	}
});

require (

			[
			'echarts',
			'echarts/chart/pie',
			'echarts/chart/bar',
			'echarts/chart/line',
			],

			function (ec) {

				var myChart = ec.init(document.getElementById('main'));
				myChart.setOption(option);

				var myChart2 = ec.init(document.getElementById('main2'));
				myChart2.setOption(option2);

				myChart.connect(myChart2);
				myChart2.connect(myChart);

				setTimeout(function (){ 
					window.onresize = function () {
						myChart.resize();
						myChart2.resize();
					}   
				},200)
			} 
);
