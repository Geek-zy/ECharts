
option = {
	title : {
		text: '一脉阳光 ' + Date_Time + '年全国患者影像例数统计图',
		subtext: '数据截止到：' + Date_Time + '年12月31日' + ' 单位: 例',
		x:'center'
	},
	tooltip : {
		trigger: 'item',
		formatter: "{a} <br/>{b} : {c} ({d}%)"
	},
	legend: {
		orient : 'vertical',
			   x : 'left',
			   data:['云服务','远程会诊','共建影像中心','独立影像中心']
	},
	calculable : true,
	series : [
	{
		name:'全年数据统计：',
		type:'pie',
		radius : '55%',
		center: ['50%', 225],
		data:[
		{value:All_3, name:'云服务'},
		{value:All_0, name:'远程会诊'},
		{value:All_1, name:'共建影像中心'},
		{value:All_2, name:'独立影像中心'}
		]
	}
	]
};

option2 = {
	tooltip : {
		trigger: 'axis',
		axisPointer : {
			type: 'shadow'
		}
	},
	legend: {
		data:['云服务','远程会诊','共建影像中心','独立影像中心']
	},
	toolbox: {
		show : true,
			 orient : 'vertical',
			 y : 'center',
			 feature : {
				 mark : {show: true},
					  magicType : {show: true, type: ['line', 'bar', 'stack', 'tiled']},
					  restore : {show: true},
					  saveAsImage : {show: true}
			 }
	},
	calculable : true,
	xAxis : [
	{
		type : 'category',
			 data : ['第一季度','第二季度','第三季度','第四季度']
	}
	],
		yAxis : [
		{
			type : 'value',
				 splitArea : {show : true}
		}
	],
		grid: {
			x2:40
		},
		series : [
		{
			name:'云服务',
			type:'bar',
			stack: '总量',
			data:[One_3, Two_3, Three_3, Four_3]
		},
		{
			name:'远程会诊',
			type:'bar',
			stack: '总量',
			data:[One_0, Two_0, Three_0, Four_0]
		},
		{
			name:'共建影像中心',
			type:'bar',
			stack: '总量',
			data:[One_1, Two_1, Three_1, Four_1]
		},
		{
			name:'独立影像中心',
			type:'bar',
			stack: '总量',
			data:[One_2, Two_2, Three_2, Four_2]
		}
	]
};

